<template>
  <div class="gxYQch">
    <NuxtLink class="jjabJD" to="/login">
      <div class="fvEvSO">
        <svg viewBox="0 0 20 20" fill="none" class="jXTFjD">
          <path d="M11.6667 6.66663L8.33334 9.99996L11.6667 13.3333" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="stroke: var(--icon-color)"></path>
        </svg>
        Login
      </div>
    </NuxtLink>
  </div>
</template>
